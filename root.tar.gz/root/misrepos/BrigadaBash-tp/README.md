# BrigadaBash-tp
integrantes:
            TATIANA FLORES;
            DELFINA GEREA;
            TOMAS GOMEZ COLLOCA;
            OSCAR GABRIEL GUERRERO GUZMAN;
  
