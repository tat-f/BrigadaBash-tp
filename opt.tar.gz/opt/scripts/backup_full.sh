#!/bin/bash

function mostrar_ayuda {
    echo "uso: $0 -o <directorio_origen> -d <directorio_destino>"
    echo "Ejemplo: $0 -o /var/log -d /backup_dir"
    echo "opciones:"
    echo " -o  Directorio origen a backupear"
    echo " -d Directorio destino donde se guardara el backup"
    echo " -help Mostrar esta ayuda"
}

#validar argumentos
if [ "$1" == "-help" ] || [ "$1" == "--help" ]; then
   mostrar_ayuda
   exit 0
fi

if [ "$#" -lt 4 ]; then
   echo "Error: debe proporcionar -o <origen> y -d <destino>" 
   mostrar_ayuda
   exit 1
fi

#parsear argumentos
while [ $# -gt 0 ]; do
    case $1 in
        -o)
           ORIGEN="$2"
           shift 2
           ;;
        -d)
           DESTINO="$2"
           shift 2
           ;;
         *)
           echo "opcion desconocida: $1"
           mostrar_ayuda
           exit 1
           ;;
    esac
done

#validar que origen y destino existan y esten montados
if ! mountpoint -q "$ORIGEN"; then
   if  [ ! -d "$ORIGEN" ]; then
       echo "Error: el directorio origen '$ORIGEN' no exite o no esta montado"
       exit 1
   fi
else
   echo "origen '$ORIGEN' esta montado"
fi

if ! mountpoint -q "$DESTINO"; then
   if [ ! -d "$DESTINO" ]; then
      echo "Error: El directorio destino '$DESTINO' no exite o no esta montado"
      exit 1
   fi
else
   echo "destino '$DESTINO' esta montado"
fi

BASENAME=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="${BASENAME}_bkp_${FECHA}.tar.gz"


echo "creando backup de '$ORIGEN' en '$DESTINO/$ARCHIVO'..."
tar -czf "${DESTINO}/${ARCHIVO}" -C "$(dirname "$ORIGEN")" "$BASENAME"

if [ $? -eq 0 ]; then 
   echo "backup completado exitosamente"
else 
   echo "error al crear el backuo" 
   exit 1
fi




